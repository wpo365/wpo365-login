<?php
namespace Wpo\Firebase\JWT;

class SignatureInvalidException extends \UnexpectedValueException
{

}
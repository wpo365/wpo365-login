<?php
namespace Wpo\Firebase\JWT;

class ExpiredException extends \UnexpectedValueException
{

}
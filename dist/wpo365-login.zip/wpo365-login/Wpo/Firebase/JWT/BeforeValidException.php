<?php
namespace Wpo\Firebase\JWT;

class BeforeValidException extends \UnexpectedValueException
{

}